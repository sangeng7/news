import React from 'react'

function ScrollTop() {
  return (
    <>
       <div className='box'>
        <a href='#root'><i class="bi bi-chevron-up"></i></a>
      </div>
    </>
  )
}

export default ScrollTop
