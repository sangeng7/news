// import React from 'react'
// import { Card } from 'react-bootstrap'
// import { Link, useParams } from 'react-router-dom'
// import data from './news'

// function Trending2() {
//     let {pid}= useParams()
//     let displaydata= data.find((a)=>a.id==id)
//     return (
//         <>
//             <Card>
//                 <Card.Img variant="top" src={displaydata.img} />
//                 <Card.Body>
//                     <Card.Title className='pb-2'><Link to={`/details/${pid}`}>{displaydata.title}</Link></Card.Title>
//                     <Card.Text>
//                         {displaydata.publishedAt}
//                     </Card.Text>
//                 </Card.Body>
//             </Card>
//         </>
//     )
// }

// export default Trending2
