const data=
[
    {
      "id": 1,
      "img": "https://i.ytimg.com/vi/8EQmBtEN22w/maxresdefault.jpg",
      "title": "BBVA, mejor banco para trabajar en España - BBVA",
      "publishedAt": "2023-03-03T06:29:20Z"

    },
    {
      "id": 2,
      "img": "https://ichef.bbci.co.uk/live-experience/cps/800/cpsprodpb/4A8C/production/_128848091_ukraine_howitzer_getty.jpg",
      "title": "Austrian Airlines mit besserem Ergebnis - ORF",
      "publishedAt": "2023-03-03T05:26:15Z"
    },
    {
      "id": 3,
      "img": "https://s3.envato.com/files/305542063/20160423_3962.jpg",
      "title": "4 pasos para atraer a los clientes que más pagan por tus servicios - Emprendedores.es",
      "publishedAt": "2023-03-03T05:23:00Z"
    },
    {
      "id": 4,
      "img": "https://s3.envato.com/files/358032117/DSC00114.jpg",
      "title": "Pleitewelle geht weiter: Nächster deutscher Mode-Händler muss Insolvenz anmelden - CHIP Online Deutschland",
      "publishedAt": "2023-03-03T05:22:45Z"
    },
    {
      "id": 5,
      "img": "https://ichef.bbci.co.uk/news/573/cpsprodpb/0A7B/production/_128838620_1c15a60a00af2628070395be965bb4517803b701.jpg",
      "title": "Nordstrom leaving Canada, cutting 2,500 jobs - Fox Business",
      "publishedAt": "2023-03-03T05:17:18Z"
    },
    {
      "id": 6,
      "img": "https://ichef.bbci.co.uk/live-experience/cps/800/cpsprodpb/5AF1/production/_128818232_gettyimages-1311837740.jpg",
      "title": "Immobilier : pourquoi tous les prix virent au rouge - Ouest-France",
      "publishedAt": "2023-03-03T05:14:05Z"
    },
    {
      "id": 7,
      "img": "https://ichef.bbci.co.uk/news/800/cpsprodpb/c43c/live/0d245d10-b81e-11ed-b6c2-1ba7821f5e70.jpg",
      "title": "5 métodos para elevar el pecho sin cirugía - ELLE",
      "publishedAt": "2023-03-03T05:10:00Z"
    },
    {
      "id": 8,
      "img": "https://ichef.bbci.co.uk/live-experience/cps/800/cpsprodpb/94A3/production/_128815083_gettyimages-598027004.jpg",
      "title": "Γαλακτοβιομηχανία: Ο μεγάλος με το πλεόνασμα σε ελληνικό  Capital.gr",
      "publishedAt": "2023-03-03T05:10:00Z"
    },
    {
      "id": 9,
      "img": "https://ichef.bbci.co.uk/live-experience/cps/800/cpsprodpb/806A/production/_128847823_newmanindexajw.jpg",
      "title": "Разглобена Tesla Model Y е шокирала шефовете на Toyota - Vesti.bg - Новини от България и света",
      "publishedAt": "2023-03-03T05:06:30Z"
    },
    {
      "id": 10,
      "img": "https://ichef.bbci.co.uk/live-experience/cps/800/cpsprodpb/4A8C/production/_128848091_ukraine_howitzer_getty.jpg",
      "title": "DOSSIER. La maison individuelle menacée de disparition ? - LaDepeche.fr",
      "publishedAt": "2023-03-03T05:04:24Z"
    }
  ]
   export default data